package com.project.entity;

import java.time.LocalDate;

public class WeeklyReport {
    private String id;
    private String week; // e.g. "Week 1 (Sprint 1 Summary)"
    private String submissionStatus = "Pending"; // Submitted, Pending
    private LocalDate submittedDate;
    private String remarks; // Mentor remarks / grades
    private String fileUrl; // Path to submitted document

    public WeeklyReport() {}

    public WeeklyReport(String id, String week, String submissionStatus, LocalDate submittedDate, String remarks, String fileUrl) {
        this.id = id;
        this.week = week;
        this.submissionStatus = submissionStatus;
        this.submittedDate = submittedDate;
        this.remarks = remarks;
        this.fileUrl = fileUrl;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getWeek() { return week; }
    public void setWeek(String week) { this.week = week; }

    public String getSubmissionStatus() { return submissionStatus; }
    public void setSubmissionStatus(String status) { this.submissionStatus = status; }

    public LocalDate getSubmittedDate() { return submittedDate; }
    public void setSubmittedDate(LocalDate submittedDate) { this.submittedDate = submittedDate; }

    public String getRemarks() { return remarks; }
    public void setRemarks(String remarks) { this.remarks = remarks; }

    public String getFileUrl() { return fileUrl; }
    public void setFileUrl(String fileUrl) { this.fileUrl = fileUrl; }
}
