package com.project.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import com.project.entity.User;

// Spring Data MongoDB generates the implementation of this interface at startup.
// save(), findAll(), findById(), deleteById() all come for free from MongoRepository.
public interface UserRepository extends MongoRepository<User, String> {
}
