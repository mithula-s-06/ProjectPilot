package com.project.entity;

import java.time.LocalDate;

public class Task {
    private String id;
    private String name;
    private LocalDate assignedDate;
    private LocalDate deadline;
    private String priority;
    private String status = "Pending"; // Pending, In Progress, Completed
    private String student;

    public Task() {}

    public Task(String id, String name, LocalDate assignedDate, LocalDate deadline, String priority, String status, String student) {
        this.id = id;
        this.name = name;
        this.assignedDate = assignedDate;
        this.deadline = deadline;
        this.priority = priority;
        this.status = status;
        this.student = student;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public LocalDate getAssignedDate() { return assignedDate; }
    public void setAssignedDate(LocalDate assignedDate) { this.assignedDate = assignedDate; }

    public LocalDate getDeadline() { return deadline; }
    public void setDeadline(LocalDate deadline) { this.deadline = deadline; }

    public String getPriority() { return priority; }
    public void setPriority(String priority) { this.priority = priority; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getStudent() { return student; }
    public void setStudent(String student) { this.student = student; }
}
